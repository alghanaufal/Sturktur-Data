#include "header.h"
int main()
{
    tree T;
    tree F;
    simpul *find;
    int i, n, m;
    char str[201];
    scanf("%d", &n);
    input data[100];

    for (i = 0; i < n; i++)
    {
        scanf("%s", &str);
        InInput(n, str, data, i);
    }
    int range;
    scanf("%d", &range);

    InTree(&T, data, n);
    spasi(T.root, 0);

    printTreePreOrder(T.root, 0, 0);
    findrange(T.root, range);

    char nama[n][201];
    for (i = 0; i < n; i++)
    {
        strcpy(nama[i], data[i].nama);
        InDell(T.root, nama[i]);
    }
    printf("\n");
    printTreePreOrder(T.root, 0, 0);
}